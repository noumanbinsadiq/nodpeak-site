=== Nodpeak — Reviews, Trust & Search Markup ===
Contributors: noumansadiq
Tags: reviews, trust, seo, structured data, schema
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add the free, open-source Nodpeak widget to your site — customer reviews, trust signals, and valid Google & AI search markup — with one setting.

== Description ==

Nodpeak adds three things to your website from one small widget: it collects and shows customer **reviews**, adds the **trust** details that turn a visitor into a phone call, and outputs valid **LocalBusiness and FAQ structured data** so Google and AI search engines can understand and recommend your business.

This plugin is the easiest way to add it on WordPress. Instead of editing your theme, you paste your **Project ID** on one settings screen and save — the widget goes live on every page, and it keeps working through theme changes and updates.

**Honest about Google stars.** Nodpeak does not pretend an on-site widget will put review stars in Google search — Google's self-serving reviews policy makes that impossible for a business's own site. Instead, Nodpeak helps you earn those stars the legitimate way (by growing your Google Business Profile reviews) and adds the structured data that genuinely helps. Everything is open source, so you can check exactly what it does: https://github.com/nodpeakapp/nodpeak

**Free forever.** No paid tier, no subscription, no view limits, and no "powered by" badge you can't remove.

= What this plugin does =

* Adds a single settings screen under **Settings → Nodpeak**.
* Injects the Nodpeak widget on your site using the Project ID you enter.
* Supports the free hosted version (default) or your own self-hosted Nodpeak server.
* Optional inline placement, if you'd rather drop the widget in a specific spot than float it.

= Where processing happens =

The plugin itself only outputs one `<script>` tag and stores your settings. All review collection, trust rendering and structured-data generation happen on your Nodpeak server (the free hosted version at app.nodpeak.com by default, or your own server if you self-host). Nothing loads or runs until you set a Project ID.

== Installation ==

1. In your WordPress admin, go to **Plugins → Add New → Upload Plugin** and upload the Nodpeak `.zip`, then click **Install Now** and **Activate**. (Or search "Nodpeak" once it's in the plugin directory.)
2. Go to **Settings → Nodpeak**.
3. Paste your **Project ID** from your Nodpeak dashboard (https://app.nodpeak.com) and click **Save Changes**.
4. That's it — visit your site and you'll see the widget.

Don't have a Project ID yet? Create one free at https://app.nodpeak.com — or self-host Nodpeak from https://github.com/nodpeakapp/nodpeak

== Frequently Asked Questions ==

= Is it really free? =

Yes. Nodpeak is free and open source (the app is AGPL-3.0; this plugin is GPLv2-or-later). No paid tier, no subscription, no view limits.

= Will this put review stars in my Google search result? =

Honestly, no — and no on-site widget can. Google's self-serving reviews policy means a business's own site can't earn star rich results from reviews it collects about itself. The stars people see come from your Google Business Profile. Nodpeak helps you grow those the legitimate way and adds the structured data that genuinely helps Google and AI understand your business.

= Do I need to edit my theme? =

No. Paste your Project ID on the settings screen and save. Nothing else.

= Where is my data stored? =

On your Nodpeak server — the free hosted version by default, or your own server if you self-host. This plugin only stores your Project ID and server URL in your WordPress options.

= Where's the source code? =

https://github.com/nodpeakapp/nodpeak

== Changelog ==

= 1.0.0 =
* First release. Settings screen + footer widget injection with Project ID, custom server URL, and optional inline placement.
