<?php
/**
 * Plugin Name:       Nodpeak — Reviews, Trust & Search Markup
 * Plugin URI:        https://nodpeak.com/
 * Description:       Adds the free Nodpeak review, trust and structured-data widget to your site. Paste your Project ID once and you're live — no theme editing, nothing to keep updated.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Nouman Sadiq
 * Author URI:        https://noumansadiq.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       nodpeak
 *
 * Nodpeak is free and open source. This plugin is a thin wrapper: it loads the
 * Nodpeak widget from your Nodpeak server using the Project ID you enter below.
 * All review, trust and structured-data processing happens on that server — the
 * plugin itself only outputs one <script> tag, and nothing runs until you set a
 * Project ID. See https://github.com/nodpeakapp/nodpeak for the source.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NODPEAK_OPT', 'nodpeak_settings' );
define( 'NODPEAK_DEFAULT_APP', 'https://app.nodpeak.com' );

/**
 * Default settings.
 *
 * @return array
 */
function nodpeak_defaults() {
	return array(
		'project_id' => '',
		'app_url'    => NODPEAK_DEFAULT_APP,
		'inline'     => 0,
	);
}

/**
 * Read the saved settings, merged over the defaults.
 *
 * @return array
 */
function nodpeak_get() {
	return wp_parse_args( get_option( NODPEAK_OPT, array() ), nodpeak_defaults() );
}

/**
 * Sanitize the settings form on save.
 *
 * @param array $input Raw input.
 * @return array
 */
function nodpeak_sanitize( $input ) {
	$out               = nodpeak_defaults();
	$out['project_id'] = isset( $input['project_id'] ) ? sanitize_text_field( $input['project_id'] ) : '';
	$url               = isset( $input['app_url'] ) ? esc_url_raw( trim( $input['app_url'] ) ) : '';
	$out['app_url']    = $url ? untrailingslashit( $url ) : NODPEAK_DEFAULT_APP;
	$out['inline']     = empty( $input['inline'] ) ? 0 : 1;
	return $out;
}

/* ----------------------------------------------------------------------------
 * Settings screen: Settings → Nodpeak
 * ------------------------------------------------------------------------- */

add_action(
	'admin_menu',
	function () {
		add_options_page( 'Nodpeak', 'Nodpeak', 'manage_options', 'nodpeak', 'nodpeak_settings_page' );
	}
);

add_action(
	'admin_init',
	function () {
		register_setting( 'nodpeak_group', NODPEAK_OPT, 'nodpeak_sanitize' );
	}
);

/**
 * Add a "Settings" link on the Plugins list row.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		$url    = admin_url( 'options-general.php?page=nodpeak' );
		$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'nodpeak' ) . '</a>';
		return $links;
	}
);

/**
 * Render the settings page.
 */
function nodpeak_settings_page() {
	$o = nodpeak_get();
	?>
	<div class="wrap">
		<h1>Nodpeak</h1>
		<p style="max-width:40em">
			Paste your <strong>Project ID</strong> from your Nodpeak dashboard and save. That's the whole setup — the review, trust and search-markup widget goes live on your site.
			<br>
			<a href="https://app.nodpeak.com" target="_blank" rel="noopener">Open your dashboard</a> &middot;
			<a href="https://nodpeak.com" target="_blank" rel="noopener">What is Nodpeak?</a>
		</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'nodpeak_group' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="nodpeak_project_id"><?php esc_html_e( 'Project ID', 'nodpeak' ); ?></label></th>
					<td>
						<input name="<?php echo esc_attr( NODPEAK_OPT ); ?>[project_id]" id="nodpeak_project_id" type="text" class="regular-text" value="<?php echo esc_attr( $o['project_id'] ); ?>" placeholder="e.g. clx1a2b3c4..." />
						<p class="description"><?php esc_html_e( 'Find this in your Nodpeak dashboard, under your project. Until it is set, this plugin adds nothing to your site.', 'nodpeak' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nodpeak_app_url"><?php esc_html_e( 'Nodpeak server URL', 'nodpeak' ); ?></label></th>
					<td>
						<input name="<?php echo esc_attr( NODPEAK_OPT ); ?>[app_url]" id="nodpeak_app_url" type="url" class="regular-text" value="<?php echo esc_attr( $o['app_url'] ); ?>" />
						<p class="description">
							<?php
							printf(
								/* translators: %s: default Nodpeak app URL. */
								esc_html__( 'Leave as %s for the free hosted version. Change it only if you self-host Nodpeak on your own server.', 'nodpeak' ),
								'<code>' . esc_html( NODPEAK_DEFAULT_APP ) . '</code>'
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Inline placement', 'nodpeak' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( NODPEAK_OPT ); ?>[inline]" value="1" <?php checked( $o['inline'], 1 ); ?> />
							<?php
							printf(
								/* translators: %s: example markup. */
								esc_html__( 'Only load where I place a %s block', 'nodpeak' ),
								'<code>&lt;div id="nodpeak"&gt;&lt;/div&gt;</code>'
							);
							?>
						</label>
						<p class="description"><?php esc_html_e( 'Leave unchecked for the default floating widget in the corner of every page.', 'nodpeak' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* ----------------------------------------------------------------------------
 * Front-end: output the Nodpeak widget tag in the footer.
 * Nothing is printed until a Project ID has been saved.
 * ------------------------------------------------------------------------- */

add_action(
	'wp_footer',
	function () {
		$o = nodpeak_get();
		if ( empty( $o['project_id'] ) ) {
			return;
		}
		$src = esc_url( $o['app_url'] . '/widget.js' );
		$pid = esc_attr( $o['project_id'] );
		if ( ! empty( $o['inline'] ) ) {
			printf(
				'<script src="%s" data-project-id="%s" data-mount="nodpeak" async></script>' . "\n",
				$src, // phpcs:ignore WordPress.Security.EscapeOutput -- esc_url() above.
				$pid  // phpcs:ignore WordPress.Security.EscapeOutput -- esc_attr() above.
			);
		} else {
			printf(
				'<script src="%s" data-project-id="%s" async></script>' . "\n",
				$src, // phpcs:ignore WordPress.Security.EscapeOutput -- esc_url() above.
				$pid  // phpcs:ignore WordPress.Security.EscapeOutput -- esc_attr() above.
			);
		}
	},
	20
);
